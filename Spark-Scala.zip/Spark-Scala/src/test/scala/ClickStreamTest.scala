import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually

class ClickStreamTest extends FlatSpec  with Matchers with Eventually   with BeforeAndAfter with SapientTestSpec {

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    import _sqlc.implicits._

    clicktestDf = _sqlc.sparkContext.parallelize(inputData).toDF()

  }

  "This test case will test Click Stream Data " should "Display the transformed Click Stream data " in {

  }
}
