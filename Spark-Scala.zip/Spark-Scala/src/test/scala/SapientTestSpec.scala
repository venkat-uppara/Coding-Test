import org.apache.spark.sql.SparkSession
import org.scalatest.{BeforeAndAfterAll, Suite}

trait SapientTestSpec extends BeforeAndAfterAll {
  this: Suite =>
  private var _sc: SparkSession = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    lazy val spark: SparkSession = {
      getSparkSession
    }
    sparkConfig.foreach { case (k, v) => spark.sparkContext.getConf.setIfMissing(k, v) }

    _sc = getSparkSession
  }

  def sparkConfig: Map[String, String] = Map.empty

  def getSparkSession: SparkSession = {

    val sparkSession = SparkSession
      .builder()
      .master("local[2]")
      .appName("Order")
      .config("spark.testing.memory", "471859200")
      .getOrCreate()
       sparkSession
  }

  override def afterAll(): Unit = {
    if (_sc != null) {
      _sc.stop()
      _sc = null
    }
    super.afterAll()
  }

  def sc: SparkSession = _sc
}
