package com.sapient;
import java.util.*;
public class RemoveDuplicatePerson {

    public  static void main(String[] args){

        final ArrayList person = new ArrayList();

        person.add(new Person("Rajesh ",21, "London"));
        person.add(new Person("Suresh",28, "California"));
        person.add(new Person("Sam", 26,"Delhi"));
        person.add(new Person("Rajesh ",21, "Gurgaon"));
        person.add(new Person("Manish",29, "Bengaluru"));

        System.out.println(person);

        Set set = new HashSet(person);

        set.addAll(person);

        System.out.println(" After removing duplicates ");

        final ArrayList newList = new ArrayList(set);

        // Print original list
        System.out.println(newList);
    }

}

class Person {

    private String name;
    private int age;
    private String location;

    public Person(String name, int age, String location) {
        this.name = name;
        this.age = age;
        this.location = location;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Person)) return false;
        Person person = (Person) o;
        return getAge() == person.getAge() &&
                Objects.equals(getName(), person.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getAge());
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", location='" + location + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
