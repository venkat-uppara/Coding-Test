package com.practice

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import com.sapient.Loggers
import org.apache.logging.log4j.LogManager
import org.joda.time.DateTime
import org.joda.time.format.{DateTimeFormat, DateTimeFormatter, ISODateTimeFormat}

object ClickStream   extends Loggers with  App {

  final val CLICK_STREAM_COL_ORDER = "user_id ,click_time ,session_num, dailyTimeSpent , monthlyTimeSpent ,userYYYYMMDD ,userYYYYMM)"

  @transient lazy val loggers = LogManager.getLogger(getClass.getName)
  val tmo1: Long = 60 * 60

  System.setProperty("hadoop.home.dir", "C:\\winutils")

  val sparkSession = SparkSession
    .builder()
    .master("local[2]")
    .appName("Order")
    .config("spark.testing.memory", "471859200")
    .getOrCreate()

  val hiveSession= HiveWarehouseSession.session(sparkSession).build()
  hiveSession.setDatabase("Click")

  val dateToTimeStamp = udf((date: String) => Option[String] {
    val parser = ISODateTimeFormat.dateTime
    val dt = parser.parseDateTime(date)
    val modifiedDate = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss").print(dt)
     modifiedDate
  })

  def reorderSourceTableSchema(columnString: String, inputdateFrame: DataFrame): DataFrame ={
    loggers.info("Column order arranging before loading into the table ")
    val columns: Array[String] = columnString.split(",")
    val outputDataFrame = inputdateFrame.select(columns.head, columns.tail:_*)

    outputDataFrame
  }

  import sparkSession.implicits._

 /*Val clickStreamDF = sparkSession.createDataFrame(Seq(
   ("2018-01-01T11:00:00.000Z","u1"),
    ("2018-01-01T12:00:00.000Z","u1"),
    ("2018-01-01T11:00:00.000Z","u2"),
    ("2018-01-02T11:00:00.000Z","u2"),
    ("2018-01-01T12:15:00.000Z","u1"))).toDF("click_time1","user_id")*/

 val clickStreamDF = hivesession.execute("select * from clickstream");

  val clickDF = clickStreamDF.withColumn("click_time",dateToTimeStamp($"clickTimestamp")).drop("click_time1")

  loggers.info("Storing the click stream data into parquet file")

  clickDF.write.parquet("C:\\sapient\\clickstream.parquet")

  val usedWindow = Window.partitionBy("user_id").orderBy("click_time")

  val clickDf = when((unix_timestamp($"click_time") - unix_timestamp(lag($"click_time",1,"2017-01-01 11:00:00.0").over(usedWindow)))/60 >= 60, 1).otherwise(0)

  val clickStream = clickDF.withColumn("session_num",sum(clickDf).over(usedWindow))
    .withColumn("userYYYYMMDD",$"click_time".substr(1,10))
    .withColumn("userYYYYMM",$"click_time".substr(1,7))

  val dailyWindow  = Window.partitionBy("userYYYYMMDD")
  val monthlyWindow   = Window.partitionBy("userYYYYMM")

 val finalDf =  clickStream.withColumn("dailyTimeSpent", sum(col("session_num")).over(dailyWindow))
               .withColumn("monthlyTimeSpent", sum(col("session_num")).over(monthlyWindow))

 val finalClickStreamDF = reorderSourceTableSchema(CLICK_STREAM_COL_ORDER,finalDf)

  try {
    finalClickStreamDF.write.bucketBy(4,"userYYYYMMDD").format(HIVE_WAREHOUSE_CONNECTOR).mode(SaveMode.Append).partitionBy("userYYYYMM")
    .option("table", "clicksStream_final")
    .save()
  } catch{
    case exp: Exception => loggers.error(": We have an error on storing data into clickStream_final" + exp.printStackTrace())
  }
}
