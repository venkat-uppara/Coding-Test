package com.sapient
import org.apache.logging.log4j.LogManager

trait Loggers {
  @transient lazy val logger = LogManager.getLogger(getClass.getName)

  def logRegularMessage(Message: String): Unit ={
    logger.info(Message)
    //logger.error(Message+" ")
    //logger.debug(Message+" ")
  }
}
